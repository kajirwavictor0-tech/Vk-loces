package com.viclocation.app

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF0B1220)
private val Panel = Color(0xFF172337)
private val Blue = Color(0xFF377DFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VicLocationApp() }
    }
}

@Composable
fun VicLocationApp() {
    var account by remember { mutableStateOf("") }
    var loggedIn by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var shareOn by remember { mutableStateOf(false) }
    var locationText by remember { mutableStateOf("Location sharing is off.") }
    var searchText by remember { mutableStateOf("Search is a demo in this starter build. Online account lookup is not connected yet.") }
    val context = androidx.compose.ui.platform.LocalContext.current

    val locationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            try {
                val lm = context.getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
                val providers = lm.getProviders(true)
                var last: Location? = null
                for (p in providers) {
                    val l = lm.getLastKnownLocation(p)
                    if (l != null && (last == null || l.time > last.time)) last = l
                }
                if (last != null) {
                    locationText = "Your device location (local demo): %.5f, %.5f".format(last.latitude, last.longitude)
                } else {
                    locationText = "Permission granted. Waiting for a GPS fix; move outdoors and try again."
                }
                shareOn = true
            } catch (_: SecurityException) {
                locationText = "Location permission was granted, but Android blocked the location read."
            }
        } else {
            shareOn = false
            locationText = "Location permission denied. Sharing remains off."
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Navy, surface = Panel)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(50.dp).background(Blue, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.LocationOn, null, tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                    Column {
                        Text("Vic Location", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Connect · Share · Locate", color = Color(0xFFB7C5DB))
                    }
                }

                if (!loggedIn) {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Welcome", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Text("Prototype profile — online sign-in isn't connected yet.", color = Color.LightGray)
                            OutlinedTextField(value = account, onValueChange = { account = it }, label = { Text("Email or phone number") }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = { if (account.isNotBlank()) loggedIn = true }, modifier = Modifier.fillMaxWidth()) { Text("Continue") }
                        }
                    }
                } else {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text("Find someone", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Phone number") }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = { searchText = if(query.isBlank()) "Enter a number first." else "No connected account found in this offline prototype. Real lookup requires an online backend and sharing consent." }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.PersonSearch, null); Spacer(Modifier.width(8.dp)); Text("Search")
                            }
                            Text(searchText, color = Color(0xFFB7C5DB))
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text("My location", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(if(shareOn) Icons.Default.Visibility else Icons.Default.VisibilityOff, null, tint = if(shareOn) Color(0xFF6EE7A0) else Color.LightGray)
                                Spacer(Modifier.width(8.dp))
                                Text(if(shareOn) "Location permission enabled (demo)" else "Sharing off")
                            }
                            Button(onClick = {
                                locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                            }, modifier = Modifier.fillMaxWidth()) { Text("Turn on my location") }
                            OutlinedButton(onClick = { shareOn = false; locationText = "Location sharing switched off in this demo." }, modifier = Modifier.fillMaxWidth()) { Text("Turn off sharing") }
                            Text(locationText, color = Color(0xFFB7C5DB))
                            Box(Modifier.fillMaxWidth().height(165.dp).background(Color(0xFF22334C), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.LocationOn, null, tint = Blue, modifier = Modifier.size(38.dp))
                                    Text("Map view comes in the next build", color = Color.White)
                                }
                            }
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, null, tint = Color(0xFF8DB5FF))
                            Spacer(Modifier.width(10.dp))
                            Text("Your location is private. This prototype reads only your device's location after you grant Android permission; it does not send it to anyone.", color = Color(0xFFCFD9E8))
                        }
                    }
                    OutlinedButton(onClick = { loggedIn = false; account = ""; shareOn = false }, modifier = Modifier.fillMaxWidth()) { Text("Sign out") }
                }
                Text("Prototype build 0.1 · Online accounts and person-to-person location sharing are not connected.", color = Color(0xFF96A6BE), fontSize = 12.sp)
            }
        }
    }
}
